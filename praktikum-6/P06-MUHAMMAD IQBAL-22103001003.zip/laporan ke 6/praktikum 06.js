const arr =[[12455, "IQBAL"], [12568, "YUSRON"], [12570, "ARIFIN"]]
function seqSearch(arr, data){
    for(let i = 0; i < arr.length; ++i){
        if(arr[i] == data){
            return false
        }
        else{
            console.log("ditemukan")
        }
    }
    return true
}
nimDicari = 12568
console.log(seqSearch(arr, nimDicari, true));
console.log(arr[1]);